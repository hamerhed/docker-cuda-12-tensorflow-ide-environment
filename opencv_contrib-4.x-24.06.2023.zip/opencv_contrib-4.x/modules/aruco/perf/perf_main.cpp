#include "perf_precomp.hpp"

CV_PERF_TEST_MAIN(aruco)
